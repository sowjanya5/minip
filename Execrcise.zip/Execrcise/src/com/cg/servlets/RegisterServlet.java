package com.cg.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.servlet.dao.UserDao;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String username=request.getParameter("user");
		String password=request.getParameter("pass");
		String mail=request.getParameter("email");
		String mobile=request.getParameter("contact");
		out.println("<html>");
		out.println("<body bgcolor='silver'>");
		//out.println("<p>user registered successfully: please login</p>");
		out.println("</body></html>");
		UserDao dao=new UserDao();
		int n=dao.register(username,password,mail,mobile);
		if(n>0){
			response.sendRedirect("login.jsp");
	
		}
		else{
		
			response.sendRedirect("register.jsp?emsg=something went wrong register agian");
			
		}

}
}

