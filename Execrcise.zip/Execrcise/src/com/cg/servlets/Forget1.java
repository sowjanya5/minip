package com.cg.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.servlet.dao.UserDao;

/**
 * Servlet implementation class Forget1
 */
@WebServlet("/Forget1")
public class Forget1 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");

		PrintWriter out = response.getWriter();

		String username = request.getParameter("username");

		String mobile = request.getParameter("mobile");

		UserDao dao = new UserDao();

		boolean flag = dao.validatePassword(username, mobile);

		if(flag) {

		out.println("<p>Enter new password.</p>");

		RequestDispatcher requestDispatcher = request.getRequestDispatcher("newpass.jsp");

		requestDispatcher.include(request, response);

		}else {

		out.println("<b style='color:red'>Mobile Number is incorrect");

		RequestDispatcher requestDispatcher = request.getRequestDispatcher("forget1.jsp");

		requestDispatcher.include(request, response);

		}

	}

}
